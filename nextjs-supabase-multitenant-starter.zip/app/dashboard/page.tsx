import { createClient } from "@/lib/supabaseServer";
import Link from "next/link";

export default async function Dashboard() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return (
      <div className="card">
        <p className="mb-3">You are not signed in.</p>
        <Link className="btn" href="/(auth)/signin">Sign in</Link>
      </div>
    );
  }

  // Show memberships (which hotels this user belongs to)
  const { data: memberships, error } = await supabase
    .from("memberships_view")
    .select("*");

  return (
    <div className="grid gap-4">
      <h1 className="text-xl font-semibold">Dashboard</h1>
      <div className="card">
        <p className="mb-2">Signed in as: {user.email}</p>
        {error && <p className="text-red-600">{error.message}</p>}
        <ul className="list-disc ml-6">
          {(memberships ?? []).map((m: any) => (
            <li key={m.hotel_id}>
              <Link className="underline" href={`/hotels/${m.hotel_id}`}>{m.hotel_name}</Link> — role: {m.role}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
