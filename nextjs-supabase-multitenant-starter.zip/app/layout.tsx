import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Hotel Multi-tenant Starter",
  description: "Next.js + Supabase starter for multi-tenant hotel apps",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="border-b">
          <div className="container py-4 flex items-center justify-between">
            <div className="font-semibold">🏨 Hotel Starter</div>
            <nav className="flex gap-4">
              <a className="btn" href="/">Home</a>
              <a className="btn" href="/dashboard">Dashboard</a>
              <a className="btn" href="/(auth)/signin">Sign in</a>
            </nav>
          </div>
        </header>
        <main className="container py-8">{children}</main>
      </body>
    </html>
  );
}
