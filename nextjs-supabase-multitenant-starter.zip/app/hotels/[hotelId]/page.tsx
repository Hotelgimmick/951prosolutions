import { createClient } from "@/lib/supabaseServer";

export default async function HotelPage({ params }: { params: { hotelId: string }}) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return <div className="card">Please sign in.</div>;

  const { data: rooms, error } = await supabase
    .from("rooms")
    .select("*")
    .eq("hotel_id", params.hotelId)
    .order("name");

  if (error) return <div className="card text-red-600">{error.message}</div>;

  return (
    <div className="grid gap-4">
      <h1 className="text-xl font-semibold">Rooms</h1>
      <div className="card">
        <ul className="list-disc ml-6">
          {(rooms ?? []).map((r: any) => (
            <li key={r.id}>{r.name} — capacity {r.capacity}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
