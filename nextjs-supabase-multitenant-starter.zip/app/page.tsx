import Link from "next/link";

export default function Home() {
  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-bold">Next.js + Supabase Multi-tenant Starter</h1>
      <p>This starter includes Supabase Auth, a multi-tenant schema, and protected dashboard routes.</p>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="card">
          <h2 className="font-semibold mb-2">Get Started</h2>
          <ol className="list-decimal ml-5 space-y-1">
            <li>Set your environment variables in <code>.env.local</code>.</li>
            <li>Run <code>npm i</code> then <code>npm run dev</code>.</li>
            <li>Apply SQL in <code>supabase/schema.sql</code> to your Supabase.</li>
          </ol>
        </div>
        <div className="card">
          <h2 className="font-semibold mb-2">Next steps</h2>
          <ul className="list-disc ml-5 space-y-1">
            <li>Create hotels and memberships for your users.</li>
            <li>Use the dashboard to manage rooms per hotel.</li>
          </ul>
        </div>
      </div>
      <div>
        <Link href="/(auth)/signin" className="btn">Sign in</Link>
      </div>
    </div>
  );
}
