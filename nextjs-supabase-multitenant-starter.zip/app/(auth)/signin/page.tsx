'use client';
import { useState } from "react";
import { createClient } from "@/lib/supabaseBrowser";

export default function SignIn() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const supabase = createClient();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithOtp({ email });
    setLoading(false);
    if (error) alert(error.message);
    else alert('Check your email for the magic link');
  }

  return (
    <div className="max-w-md mx-auto card">
      <h1 className="text-xl font-semibold mb-4">Sign in</h1>
      <form onSubmit={onSubmit} className="space-y-3">
        <input className="input" type="email" placeholder="you@email.com"
          value={email} onChange={(e)=>setEmail(e.target.value)} />
        <button className="btn" disabled={loading}>
          {loading ? 'Sending…' : 'Send magic link'}
        </button>
      </form>
    </div>
  );
}
