-- Enable required extensions
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- Tenants (hotels)
create table if not exists public.hotels (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz default now()
);

-- Profiles linked to auth.users
create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz default now()
);

-- User membership per hotel (role per tenant)
create table if not exists public.memberships (
  hotel_id uuid references public.hotels(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  role text check (role in ('owner','admin','staff','guest')) default 'guest',
  created_at timestamptz default now(),
  primary key (hotel_id, user_id)
);

-- Example resource table bound to a tenant
create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  hotel_id uuid references public.hotels(id) on delete cascade,
  name text not null,
  capacity int not null default 2,
  created_at timestamptz default now()
);

-- Helpful view for dashboard
create or replace view public.memberships_view as
select m.hotel_id, h.name as hotel_name, m.user_id, m.role, m.created_at
from public.memberships m
join public.hotels h on h.id = m.hotel_id;

-- RLS
alter table public.memberships enable row level security;
alter table public.rooms enable row level security;
alter table public.hotels enable row level security;
alter table public.profiles enable row level security;

-- Policies: profiles (owner only)
create policy "profiles_self_select" on public.profiles
for select using (auth.uid() = user_id);
create policy "profiles_self_upsert" on public.profiles
for insert with check (auth.uid() = user_id);
create policy "profiles_self_update" on public.profiles
for update using (auth.uid() = user_id);

-- Hotels: visible if user is a member
create policy "hotels_by_membership" on public.hotels
for select using (
  exists (select 1 from public.memberships m
          where m.hotel_id = hotels.id and m.user_id = auth.uid())
);

-- Rooms: read if member, write if admin/owner
create policy "rooms_read_by_members" on public.rooms
for select using (
  exists (select 1 from public.memberships m
          where m.hotel_id = rooms.hotel_id and m.user_id = auth.uid())
);
create policy "rooms_write_admin_owner" on public.rooms
for insert with check (
  exists (select 1 from public.memberships m
          where m.hotel_id = rooms.hotel_id and m.user_id = auth.uid()
            and m.role in ('owner','admin'))
);
create policy "rooms_update_admin_owner" on public.rooms
for update using (
  exists (select 1 from public.memberships m
          where m.hotel_id = rooms.hotel_id and m.user_id = auth.uid()
            and m.role in ('owner','admin'))
);
create policy "rooms_delete_admin_owner" on public.rooms
for delete using (
  exists (select 1 from public.memberships m
          where m.hotel_id = rooms.hotel_id and m.user_id = auth.uid()
            and m.role in ('owner','admin'))
);
